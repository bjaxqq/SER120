package week12.Assignment3.Q2TicTacToe;

public class TicTacToePrinterDriver {
    public static void main(String[] args) {
        TicTacToe game = new TicTacToe();
        game.play();
    }
}